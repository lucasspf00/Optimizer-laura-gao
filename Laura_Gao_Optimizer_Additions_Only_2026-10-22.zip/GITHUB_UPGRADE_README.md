# Laura Gao Optimizer — GitHub-Ready Additive Upgrade

**Status:** Additive, opt-in goal-planning upgrade for the user's **19 October 2026 GitHub ZIP**. The original score-model algorithm is **not in the supplied GitHub ZIP** and is therefore **not changed or re-created** here. The source `optimizer.py`, `app.py`, `market_data.py`, `projections.py`, `requirements.txt`, original examples, and original tests are byte-for-byte preserved.

## New functionality

A second Streamlit page, **Laura Goal Planning**, adds beginning-of-2033 nominal operating-liability calculations, scenario-based reserve sizing, independently simulated 2027–2033 growth, illustrative 2033 facility capacity after a separate reserve and capital cushion, conditional 2031-to-2033 co-sponsor range, uploaded-data ETF issuer overlap review, and transparent two-year sequence-risk calculations.

**Your old stock page still works as before.** The new page is independent: its forward return/volatility values are manually supplied and should not be mistaken for optimized stock-sleeve estimates or your separate score-model results.

### How to deploy (read before uploading)

**Do not upload the ZIP file itself to your GitHub repository expecting Streamlit to run it. Extract the archive first.** Keep folder paths exactly as shown below. Prefer a new branch (`goal-based-upgrade`) for a safe trial; branching is recommended but **not required**. Streamlit should continue pointing to the existing `main` branch until you intentionally deploy the upgrade.

1. Open the repository `lucasspf00/Optimizer-laura-gao` and create branch `goal-based-upgrade` from `main` (recommended).
2. Extract this ZIP to a temporary local folder. The archive contains a single `Optimizer-laura-gao-main/` directory, just like the supplied source.
3. Copy the contents of `Optimizer-laura-gao-main/` to the root of your locally cloned GitHub repository, preserving the nested optimizer folder name. Overwrite only if deliberately synchronizing with the EXACT supplied 19 October snapshot; see caution below.
4. Run `python -m pytest -q` while inside `Laura_Gao_Stocks_Only_Sharpe_Sortino_5_to_25/`. We executed 126 passing tests in the available local environment.
5. On a Python **3.12** environment, install the unchanged `requirements.txt`, then run `streamlit run app.py` while inside `Laura_Gao_Stocks_Only_Sharpe_Sortino_5_to_25/`. Navigate between the original stock optimizer and `Laura Goal Planning` using Streamlit's sidebar page selector.
6. If your Streamlit Cloud app has a main-file path, keep it `Laura_Gao_Stocks_Only_Sharpe_Sortino_5_to_25/app.py` (relative to the GitHub repository root). Do NOT select the new page file as the main-file path.
7. Use a second, **temporary** Streamlit deployment pointed at branch `goal-based-upgrade` if you want a live visual check before merging. Only merge after confirming real Yahoo data, page loading, and client output assumptions. An existing app deployed from `main` will otherwise keep serving `main`.

### CAUTION: GitHub snapshots

This ZIP is based on the user-supplied `Optimizer-laura-gao-main (4).zip`, not a fresh GitHub API checkout. Before copying it into a repository that has since changed, compare your current `app.py` and `optimizer.py` to this ZIP. The safest minimal upgrade is to add **only** these files from the ZIP:

- `Laura_Gao_Stocks_Only_Sharpe_Sortino_5_to_25/reserve.py`
- `Laura_Gao_Stocks_Only_Sharpe_Sortino_5_to_25/simulation.py`
- `Laura_Gao_Stocks_Only_Sharpe_Sortino_5_to_25/goal_optimizer.py`
- `Laura_Gao_Stocks_Only_Sharpe_Sortino_5_to_25/portfolio_analysis.py`
- `Laura_Gao_Stocks_Only_Sharpe_Sortino_5_to_25/stress.py`
- `Laura_Gao_Stocks_Only_Sharpe_Sortino_5_to_25/pages/1_Laura_Goal_Planning.py`
- `Laura_Gao_Stocks_Only_Sharpe_Sortino_5_to_25/tests/test_goal_upgrade.py`
- `Laura_Gao_Stocks_Only_Sharpe_Sortino_5_to_25/UPGRADE_METHODS.md`
- Root docs `GITHUB_UPGRADE_README.md`, `CHANGES_AND_VERIFICATION.md`, `SOURCE_SHA256_MANIFEST.csv`

### Keep your current algorithm

- `optimizer.py`: original seeded multi-start SLSQP, 40% Sharpe / 60% Sortino by default, 5%–25% min/max within stock sleeve; **unchanged**.
- Your **separate** −100 to +100 Fundamental/Risk/Final scoring algorithm is **not contained in this ZIP**. The new goal page cannot use scores it has not been provided, and it makes no claim otherwise.
- Original `app.py`: same historical-data and ticker allocation behavior, same default sample tickers and $20k budget. Manually change to your current tickers and **$25k** individual-stock budget in the original sidebar when relevant.
- Original `projections.py`: original deterministic 2027–2042 illustration; unchanged. New planning logic is parallel and explicitly reserve-first.

### Verification boundary

- Locally executed: 126 automated tests passed (original tests plus new tests). All Python files compiled.
- Not verified in this environment: real Streamlit page runtime (Streamlit not installed and package network disabled), Python 3.12 pinned-dependency integration, live Yahoo Finance, Streamlit Cloud deployment, future return distributions, actual Treasury maturities/prices, real ETF constituent holdings, and competition platform eligibility.
- Simulation probabilities depend on the user's forward-looking annual return and volatility assumptions. They are NOT financial guarantees.
- `pages/` is Streamlit's documented built-in multipage directory convention. Its integration must still be visually tested in your deployed app.
