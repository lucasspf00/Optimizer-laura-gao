"""Explicit ETF look-through from an as-of-dated user-supplied holdings CSV.

No ETF constituents are silently fabricated, assumed static, or pulled via web.
This does NOT alter the original stock-only optimizer's inputs or constraints.
"""
from __future__ import annotations
import numpy as np
import pandas as pd

REQUIRED = {"ETF", "Ticker", "Weight"}


def validate_holdings(holdings: pd.DataFrame) -> pd.DataFrame:
    """Weight is a decimal fraction of ONE ETF: 0.015 == 1.5%."""
    if not REQUIRED <= set(holdings.columns):
        raise ValueError("Holdings CSV needs ETF,Ticker,Weight (decimal fractions).")
    frame = holdings.copy()
    frame["ETF"] = frame["ETF"].astype(str).str.upper().str.strip()
    frame["Ticker"] = frame["Ticker"].astype(str).str.upper().str.strip()
    frame["Weight"] = pd.to_numeric(frame["Weight"], errors="raise")
    if frame.empty or not (frame["ETF"].str.len().gt(0).all() and frame["Ticker"].str.len().gt(0).all()):
        raise ValueError("ETF holdings cannot be empty or missing tickers.")
    if (frame["Weight"] < 0).any() or not np.isfinite(frame["Weight"]).all() or (frame["Weight"] > 1).any():
        raise ValueError("ETF weights must be decimal fractions between 0 and 1.")
    if frame.duplicated(["ETF", "Ticker"]).any():
        raise ValueError("Duplicate ETF/Ticker entries are not allowed; consolidate them first.")
    if (frame.groupby("ETF")["Weight"].sum() > 1.000001).any():
        raise ValueError("ETF holdings sum to more than 100%; check Weight units.")
    return frame


def overlap_table(holdings: pd.DataFrame, stock_tickers: list[str],
                  etfs: tuple[str, ...] = ("VTI", "VBR", "VXUS"), max_holding: float = .015) -> pd.DataFrame:
    frame = validate_holdings(holdings)
    if not 0 <= max_holding <= 1:
        raise ValueError("max_holding must be a decimal fraction 0..1.")
    lookup = {(r.ETF, r.Ticker): float(r.Weight) for r in frame.itertuples()}
    ETF_list = tuple(s.upper() for s in etfs)
    present = set(frame["ETF"])
    rows = []
    for ticker in stock_tickers:
        ticker = ticker.upper().strip()
        row = {"Ticker": ticker}
        for etf in ETF_list:
            # Unlisted in a complete-snapshot *known ETF* means 0 in that snapshot.
            # Without a certified complete holdings file, absence is UNVERIFIED.
            row[f"{etf} holding (%)"] = (round(100 * lookup[(etf, ticker)], 5)
                                             if (etf, ticker) in lookup else np.nan)
        vals = [lookup[(e, ticker)] for e in ETF_list if (e, ticker) in lookup]
        row["Confirmed >1.5% violation"] = any(v > max_holding for v in vals)
        row["Status"] = "VIOLATION" if row["Confirmed >1.5% violation"] else ("PARTIAL/UNKNOWN" if any((e,ticker) not in lookup for e in ETF_list) else "WITHIN CAP")
        rows.append(row)
    return pd.DataFrame(rows)


def lookthrough_weights(etf_allocations: dict[str, float], stock_allocations: dict[str, float],
                        holdings: pd.DataFrame) -> pd.DataFrame:
    """Total portfolio fractions: direct company weight + Σ ETF_weight × constituent_weight.

    Missing constituents are NOT interpreted as zeros in the confidence warning.
    """
    frame = validate_holdings(holdings)
    alloc = {k.upper(): float(v) for k,v in etf_allocations.items()}
    direct = {k.upper(): float(v) for k,v in stock_allocations.items()}
    if not all(np.isfinite(w) and 0 <= w <= 1 for w in list(alloc.values())+list(direct.values())):
        raise ValueError("Portfolio weights must be decimal fractions between 0 and 1.")
    if sum(alloc.values()) + sum(direct.values()) > 1.000001:
        raise ValueError("ETF + direct equity weights cannot exceed 100% of total capital.")
    df = frame[frame.ETF.isin(alloc)].copy()
    df["Indirect (%)"] = df.apply(lambda r: 100 * alloc[r["ETF"]] * r["Weight"], axis=1)
    indirect = df.groupby("Ticker")["Indirect (%)"].sum().to_dict()
    rows=[]
    for ticker in sorted(set(indirect)|set(direct)):
        d = 100 * direct.get(ticker,0)
        i = indirect.get(ticker,0)
        rows.append({"Ticker":ticker,"Direct total portfolio (%)":d,"Confirmed indirect ETF (%)":i,"Known combined (%)":d+i})
    return pd.DataFrame(rows).sort_values("Known combined (%)",ascending=False)
