"""Standalone regression suite: NEW planning modules, unchanged stock optimizer."""
import numpy as np
import pandas as pd
import pytest
from reserve import (deterministic_reserve_pv, required_reserve_by_path,
                     reserve_success_mask, stochastic_reserve_quantile,
                     reserve_sensitivity, wilson_interval)
from simulation import annual_gross_lognormal, full_wealth_until_2033, project_from_known_2031
from goal_optimizer import facility_capacity, sponsor_range, funding_scenario
from portfolio_analysis import validate_holdings, overlap_table, lookthrough_weights
from stress import one_year_shock, sequence_withdrawals


def test_reserve_zero_yield():
    assert deterministic_reserve_pv(0) == 500_000


def test_reserve_flat_three_percent():
    assert deterministic_reserve_pv(.03) == pytest.approx(439305.4460939552,abs=.01)


def test_reserve_zero_spot_timing():
    assert deterministic_reserve_pv(np.zeros(10)) == pytest.approx(500000)


def test_reserve_curve_and_flat_agree():
    assert deterministic_reserve_pv([.03]*10) == pytest.approx(deterministic_reserve_pv(.03))


def test_reserve_includes_immediate_payment():
    assert deterministic_reserve_pv(999) > 50000


def test_invalid_spot_vector():
    with pytest.raises(ValueError): deterministic_reserve_pv([.03]*9)


def test_invalid_flat_spot_negative_one():
    with pytest.raises(ValueError): deterministic_reserve_pv(-1)


def test_reserve_required_by_path():
    assert required_reserve_by_path(np.ones((3,9))).tolist() == [500000]*3


def test_reserve_path_three_percent():
    val = required_reserve_by_path(np.full((4,9),1.03))
    assert np.allclose(val,deterministic_reserve_pv(.03))


def test_pathwise_initial_reserve_success():
    assert reserve_success_mask(500000,np.ones((4,9))).tolist() == [True]*4
    assert not any(reserve_success_mask(499999,np.ones((4,9))))


def test_reserve_path_shape():
    with pytest.raises(ValueError): required_reserve_by_path(np.ones((10,10)))


def test_reserve_zero_gross_rejected():
    with pytest.raises(ValueError): required_reserve_by_path(np.zeros((10,9)))


def test_reserve_target_quantile_empirical_success():
    rng=np.random.default_rng(19)
    gross=np.exp(rng.normal(.03,.1,size=(3000,9)))
    r=stochastic_reserve_quantile(gross,.99)
    assert np.mean(reserve_success_mask(r,gross)) >= .99
    assert np.mean(reserve_success_mask(r-.10,gross)) <= np.mean(reserve_success_mask(r,gross))


def test_reserve_probability_sensitivity_increasing():
    gross=annual_gross_lognormal(.03,.10,2000,9,2026)
    results=reserve_sensitivity(gross)
    values=[x['Modeled reserve ($)'] for x in results]
    assert values == sorted(values)
    assert all(x['Empirical success']>=x['Target']-1e-12 for x in results)


def test_interval_bounds():
    l,u=wilson_interval(950,1000)
    assert 0 <= l < .95 < u <= 1


def test_interval_100_success_is_not_certain():
    lo,hi=wilson_interval(1000,1000)
    assert lo < 1 and hi == 1


def test_log_returns_shape_and_positive():
    gross=annual_gross_lognormal(.06,.15,10000,6,2026)
    assert gross.shape == (10000,6) and np.all(gross > 0)


def test_lognormal_arithmetic_calibration():
    gross=annual_gross_lognormal(.06,.15,50000,10,16)
    assert abs(np.mean(gross)-1.06)<.005
    assert abs(np.std(gross)-.15)<.005


def test_log_returns_seed_reproducible():
    assert np.array_equal(annual_gross_lognormal(.06,.15,100,6,1),annual_gross_lognormal(.06,.15,100,6,1))


def test_zero_vol_exact_gross():
    assert np.array_equal(annual_gross_lognormal(.06,0,100,6,1),np.full((100,6),1.06))


def test_bad_mean_rejected():
    with pytest.raises(ValueError): annual_gross_lognormal(-1,.1,100,6,1)


def test_wharton_zero_return_2027_2028():
    result=full_wealth_until_2033(np.ones((10,6)))
    assert np.all(result['Beginning 2031 wealth']==450000)
    assert np.all(result['Beginning 2033 wealth']==450000)


def test_wharton_6pct_matches_original_projection():
    results=full_wealth_until_2033(np.full((4,6),1.06))
    assert results['Beginning 2031 wealth'][0]==pytest.approx(557395.488)
    assert results['Beginning 2033 wealth'][0]==pytest.approx(626289.5703168)


def test_2031_two_year_forward_exact():
    x=project_from_known_2031(500000,np.array([[1.1,.9],[1.,1.]]))
    assert x.tolist() == pytest.approx([495000,500000])


def test_facility_reserve_first():
    cap=facility_capacity(np.array([200000,500000,1000000]),500000,.15,0)
    assert cap.tolist()==pytest.approx([0,0,350000])


def test_facility_retained_cash_floor():
    assert facility_capacity(800000,500000,.10,200000)==pytest.approx(100000)


def test_facility_bad_flex_rejected():
    with pytest.raises(ValueError): facility_capacity(800000,500000,1.5)


def test_sponsor_percentile_and_probability():
    wealth=np.array([500000,600000,700000,800000,900000],dtype=float)
    result=sponsor_range(wealth,500000,0,0,lower_percentile=.2,upper_percentile=.8)
    assert result['Median ($)'] == pytest.approx(200000)
    assert result['Lower ($)'] < result['Median ($)'] < result['Upper ($)']
    assert .5 < result['Probability at least lower'] <= 1


def test_joint_goal_funding_zero_vol_success_when_sufficient():
    wealth=np.full(100,600000.)
    result=funding_scenario(wealth,500000,np.ones((100,9)))
    assert result['Estimated full operating success']==1
    assert result['Cannot establish target reserve']==0


def test_joint_goal_funding_zero_vol_fail_when_insufficient():
    wealth=np.full(100,400000.)
    result=funding_scenario(wealth,500000,np.ones((100,9)))
    assert result['Estimated full operating success']==0
    assert result['Cannot establish target reserve']==1
    assert np.all(result['Capacity vector ($)']==0)


def test_joint_goal_stress_varies():
    reserves=annual_gross_lognormal(.03,.1,1000,9,99)
    r=stochastic_reserve_quantile(reserves,.99)
    wealth=np.linspace(350000,800000,1000)
    funded=funding_scenario(wealth,r,reserves)
    assert 0 < funded['Estimated full operating success'] < 1


def test_portfolio_overlap_table_keeps_unknown():
    df=pd.DataFrame({'ETF':['VTI','VTI','VBR'], 'Ticker':['PGR','MA','PGR'],'Weight':[.0017,.0059,.001]})
    x=overlap_table(df,['PGR','MA'])
    assert x.loc[x.Ticker.eq('PGR'),'Status'].iloc[0]=='PARTIAL/UNKNOWN'
    assert np.isnan(x.loc[x.Ticker.eq('PGR'),'VXUS holding (%)'].iloc[0])


def test_portfolio_overlap_violation():
    df=pd.DataFrame({'ETF':['VTI','VBR','VXUS'], 'Ticker':['ABC']*3,'Weight':[.016,.0,.0]})
    x=overlap_table(df,['ABC'])
    assert x.iloc[0]['Status']=='VIOLATION'


def test_portfolio_weight_lookthrough():
    df=pd.DataFrame({'ETF':['VTI','VBR'], 'Ticker':['MA','MA'],'Weight':[.006,.001]})
    x=lookthrough_weights({'VTI':.3,'VBR':.1},{'MA':.025},df)
    assert x.iloc[0]['Known combined (%)']==pytest.approx(2.5+.18+.01)


def test_etf_bad_weight_rejected():
    with pytest.raises(ValueError): validate_holdings(pd.DataFrame({'ETF':['VTI'], 'Ticker':['PGR'],'Weight':[1.5]}))


def test_etf_excessive_total_rejected():
    with pytest.raises(ValueError): validate_holdings(pd.DataFrame({'ETF':['VTI']*2,'Ticker':['PGR','MA'],'Weight':[.7,.6]}))


def test_etf_duplicate_rows_rejected():
    with pytest.raises(ValueError): validate_holdings(pd.DataFrame({'ETF':['VTI']*2,'Ticker':['PGR','PGR'],'Weight':[.1,.1]}))


def test_weighted_shock():
    loss=one_year_shock({'stocks':.25,'rest':.75},{'stocks':-.4,'rest':0})
    assert loss==pytest.approx(-.10)


def test_shock_missing_class_rejected():
    with pytest.raises(ValueError): one_year_shock({'a':1},{'b':-.1})


def test_sequence_order_different():
    a,b=sequence_withdrawals(600000,-.2,.25)
    assert a==pytest.approx(487500)
    assert b==pytest.approx(510000)
    assert b-a==pytest.approx(22500)


def test_sequence_insufficient_returns_nan():
    a,b=sequence_withdrawals(40000,-.2,.25)
    assert np.isnan(a) and np.isnan(b)
