"""Transparent shocks and a two-year liability sequence-risk calculation.

Illustrations, not historically calibrated crises or full-asset VaR.
"""
from __future__ import annotations
import numpy as np


def one_year_shock(portfolio_weights: dict[str,float], asset_shocks: dict[str,float]) -> float:
    """Total simple portfolio shock Σ weight_i × simple shock_i.

    Every weight class must be supplied a shock (including bonds and cash).
    """
    weights={str(k):float(v) for k,v in portfolio_weights.items()}
    shocks={str(k):float(v) for k,v in asset_shocks.items()}
    if set(weights)!=set(shocks) or not np.isclose(sum(weights.values()),1,atol=1e-8):
        raise ValueError("Shock must be provided for every asset-class bucket and weights sum to one.")
    if any(not np.isfinite(v) or v < 0 for v in weights.values()) or any(not np.isfinite(v) or v < -1 for v in shocks.values()):
        raise ValueError("Weights must be nonnegative, shocks >= -100%, and all values finite.")
    return sum(weights[k]*shocks[k] for k in weights)


def sequence_withdrawals(starting_balance:float, first_return:float, second_return:float,
                        payment:float=50_000.) -> tuple[float,float]:
    """Two years, $50k paid at the start of BOTH years; order affects ending wealth.

    Returns are decimal simple annual returns. If insufficient wealth for an
    obligation, the result is an INVALID plan, not automatic external funding.
    """
    vals=(starting_balance,first_return,second_return,payment)
    if not all(np.isfinite(v) for v in vals) or starting_balance < 0 or payment <= 0 or min(first_return,second_return) <= -1:
        raise ValueError("Invalid starting wealth, payment, or annual return.")
    def run(a,b):
        w=starting_balance
        for rate in (a,b):
            if w + 1e-8 < payment:
                return np.nan
            w=(w-payment)*(1+rate)
        return float(w)
    return run(first_return,second_return),run(second_return,first_return)
