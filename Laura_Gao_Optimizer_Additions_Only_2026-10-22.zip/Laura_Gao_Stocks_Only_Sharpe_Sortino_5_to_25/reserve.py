"""Laura Gao operating liabilities: beginning-of-year $50k, 2033 through 2042.

ADDITIONAL planning module. Does not change the preexisting stock optimizer.
All yields and random return distributions are assumptions, NOT quoted Treasury prices.
"""
from __future__ import annotations

from dataclasses import dataclass
from statistics import NormalDist
import numpy as np

ANNUAL_OPERATING_PAYMENT = 50_000.0
PAYMENT_YEARS = tuple(range(2033, 2043))


def _check_amount(amount: float) -> float:
    amount = float(amount)
    if not np.isfinite(amount) or amount <= 0:
        raise ValueError("Operating payment must be a finite, positive dollar amount.")
    return amount


def deterministic_reserve_pv(
    yield_rate: float | list[float] | np.ndarray,
    payment: float = ANNUAL_OPERATING_PAYMENT,
    n_payments: int = len(PAYMENT_YEARS),
) -> float:
    """Present-value liability benchmark at START of 2033, t=0 immediate payment.

    Scalar yield: flat effective annual rate. Length-n vector: annual spot yield
    for each payment maturity t=0..n-1; not year-by-year reinvestment rates.
    Does not price actual bonds, coupons, transaction costs or reinvestment risk.
    """
    payment = _check_amount(payment)
    if not isinstance(n_payments, int) or n_payments < 1:
        raise ValueError("At least one beginning-of-year payment is required.")
    rates = np.asarray(yield_rate, dtype=float)
    if rates.ndim == 0:
        rates = np.full(n_payments, float(rates))
    if rates.shape != (n_payments,) or not np.all(np.isfinite(rates)) or np.any(rates <= -1):
        raise ValueError("Supply one valid annual yield or one valid spot yield per liability maturity.")
    t = np.arange(n_payments)
    return float(np.sum(payment / (1.0 + rates) ** t))


def required_reserve_by_path(
    annual_gross_returns: np.ndarray,
    payment: float = ANNUAL_OPERATING_PAYMENT,
) -> np.ndarray:
    """Exact pathwise cash needed at start 2033 for beginning-year liabilities.

    Shape (N,9): gross factors earned in 2033..2041 between 10 payments.
    Includes immediate 2033 $50k. Gross factors must be positive finite numbers.
    """
    payment = _check_amount(payment)
    growth = np.asarray(annual_gross_returns, dtype=float)
    if growth.ndim != 2 or growth.shape[1] != len(PAYMENT_YEARS) - 1 or not np.all(np.isfinite(growth)) or np.any(growth <= 0):
        raise ValueError("Expected (paths, 9) positive gross annual returns for years 2033–2041.")
    discount_factors = np.cumprod(growth, axis=1)
    return payment * (1.0 + np.sum(1.0 / discount_factors, axis=1))


def reserve_success_mask(starting_reserve: float | np.ndarray, annual_gross_returns: np.ndarray,
                         payment: float = ANNUAL_OPERATING_PAYMENT) -> np.ndarray:
    necessary = required_reserve_by_path(annual_gross_returns, payment=payment)
    reserves = np.asarray(starting_reserve, dtype=float)
    if not np.all(np.isfinite(reserves)) or np.any(reserves < 0):
        raise ValueError("Starting reserve must be nonnegative and finite.")
    if reserves.ndim > 1 or (reserves.ndim == 1 and reserves.shape != necessary.shape):
        raise ValueError("Reserve must be a scalar or one amount per simulated path.")
    return reserves + 1e-7 >= necessary


def _valid_target(target: float) -> float:
    target = float(target)
    if not np.isfinite(target) or not 0 < target <= 1:
        raise ValueError("Success target must be between 0 (exclusive) and 1 (inclusive).")
    return target


def stochastic_reserve_quantile(gross_returns: np.ndarray, target_success: float,
                                payment: float = ANNUAL_OPERATING_PAYMENT) -> float:
    """Smallest empirical target-success reserve using common simulated paths.

    An order statistic of path-specific present values; no black-box optimizer.
    Statistical model reliability depends on return assumptions and sampling.
    """
    target_success = _valid_target(target_success)
    required = required_reserve_by_path(gross_returns, payment=payment)
    return float(np.quantile(required, target_success, method="higher"))


def reserve_sensitivity(gross_returns: np.ndarray,
                        targets: tuple[float, ...] = (0.95, 0.99, 0.995, 0.999)) -> list[dict]:
    required = required_reserve_by_path(gross_returns)
    result = []
    for target in targets:
        quote = stochastic_reserve_quantile(gross_returns, target)
        result.append({
            "Target": target,
            "Modeled reserve ($)": quote,
            "Empirical success": float(np.mean(quote + 1e-7 >= required)),
            "Simulated paths": len(required),
        })
    return result


def wilson_interval(success_count: int, paths: int, confidence: float = 0.95) -> tuple[float, float]:
    """Approximate binomial interval for sampling error CONDITIONAL on assumptions."""
    if not isinstance(paths, int) or paths <= 0 or not isinstance(success_count, int) or not 0 <= success_count <= paths:
        raise ValueError("Invalid number of paths/successes.")
    if not 0 < confidence < 1:
        raise ValueError("confidence must be strictly between 0 and 1.")
    z = NormalDist().inv_cdf(0.5 + confidence / 2)
    p = success_count / paths
    den = 1 + z * z / paths
    center = (p + z * z / (2 * paths)) / den
    half = z / den * np.sqrt(p * (1 - p) / paths + z * z / (4 * paths * paths))
    return max(0.0, float(center - half)), min(1.0, float(center + half))
