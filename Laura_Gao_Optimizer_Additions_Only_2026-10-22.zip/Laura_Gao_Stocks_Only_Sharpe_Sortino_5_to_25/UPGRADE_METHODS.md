# Additional Laura Gao goal-planning model: mathematical specification

## Relationship to unchanged systems

This upgrade **adds** an independent Streamlit planning page and five planning modules. It **does not modify** `app.py`, `optimizer.py`, `market_data.py`, `projections.py`, `requirements.txt`, or the separate external −100 to +100 company-score algorithm. The original optimization of stocks in a bounded, long-only **stock sleeve** remains completely independent of the new forward-looking assumptions. The separate Google Doc *Laura Gao Portfolio Optimizer — Complete Mathematical Specification, Architecture & Independent Validation* documents the original implementation in greater detail.

## Client model and timing

The official Gao case specifies $300,000 contributed at the **beginning** of 2027, $150,000 at the **beginning** of 2028, a 2031 co-sponsor communication milestone, and a separate operating reserve at the **beginning** of 2033 supporting ten fixed nominal $50,000 beginning-year operating commitments during 2033–2042. No inflation is added to those specified nominal $50k obligations. WInS's $100,000 simulator is never injected into the client's long-term financial assets.

## 1. Operating reserve (`reserve.py`)

For a hypothetical flat effective annual rate y, the present value at the **beginning of 2033** is

`R_PV = sum(50,000/(1+y)^t for t in 0..9)`.

The t=0 first payment is immediate; at 0% y: $500,000. At hypothetical 3% y: approximately $439,305.45. The function also accepts 10 spot yields y_t (effective annual maturity-specific rates): `sum(50,000/(1+y_t)^t)`; this is not an actual bond market price. Spot rates and cash-flow matching require verified 2033 Treasury bids, coupons, tax/fee handling, and maturity dates.

For stochastic reserve return paths, 9 annual gross return factors `G_j` between 10 payments, the **pathwise** liability reserve is:

`R_required(path) = 50,000 * [1 + sum_{t=1..9} 1/prod_{j=0..t-1}(G_j)]`.

Each simulated reserve requirement is an exact present-value solution *for that realized path*, assuming reserve earnings can be compounded after paying beginning-year obligations. For target p in {95%,99%,99.5%,99.9%}, `stochastic_reserve_quantile` returns the empirical p quantile using the `higher` order statistic. An entirely separate simulation draws the *test* reserve gross factors, so displayed path success is not computed on the exact reference paths used to size the reserve. This is a simulation sensitivity, **not guaranteed capital preservation or a constructed Treasury ladder**.

## 2. Forward annual return simulation (`simulation.py`)

The user enters an externally assumed **arithmetic mean annual simple return** m and **annual standard deviation of annual simple returns** s separately for (a) the whole main portfolio and (b) the reserve portfolio. These are not inferred from the stock-only Sharpe–Sortino optimizer. To keep modeled wealth nonnegative, gross annual returns are lognormal `G = exp(a+bZ)` for standard-normal Z, where

`b² = ln(1+(s/(1+m))²)` and `a = ln(1+m)-b²/2`.

Consequently E[G−1]=m and Std[G−1]=s for each year. This is a **constant-parameter, i.i.d.** scenario model, not an empirical guarantee; no fat tails, time-varying regimes, portfolio covariance, or crash clustering. A zero volatility assumption produces a deterministic 1+m gross factor each year. Given paths, for years y=2027..2032:

`W_end(y) = (W_start(y) + C_y)*G_y`, where C_2027=300k, C_2028=150k, all other C_y=0.

Store opening wealth at beginning 2031 before the year-2031 gross return and opening wealth at beginning 2033 after year-2032 gross return. Zero-volatility m=6% reproduces the original `projections.py` beginning-2031 ~$557,395.49 and beginning-2033 ~$626,289.57. Distinguish 2033 *opening* assets from the amount remaining after immediately funding that year's $50k payment.

## 3. Facility and funding (`goal_optimizer.py`)

Given start-of-2033 assets `W`, reserved cash target R, minimum flexible capital `F_fixed`, and relative flexibility fraction f, compute

`FlexibleRequired = max(F_fixed, f*W)` and
`FacilityCapacity = max(W-R-FlexibleRequired, 0)`.

The facility is only offered after **R is budgeted**, preventing the original model's immediate-reserve omission. If `W < R`, the facility capacity is 0 and full R cannot be set aside. The model transfers `min(W,R)` to the reserve, and independently tests whether **all** ten dated payments are affordable along fresh simulated reserve gross-return paths. `FundingSuccess = 1[ min(W,R) >= R_required(path) ]`, one indicator per joint path. The mean of the indicators is the model-conditional funding-success frequency, and a 95% **Wilson binomial interval** quantifies *sampling error* of that frequency (NOT model risk).

The remainder is retained as flexible resources and facility contribution only, and not itself projected through 2042. In particular, this system is **not** a fully dynamic joint wealth optimizer or allocation glide path; it quantifies a reserve-first planning decomposition using exogenous rates and externally selected policy inputs.

## 4. 2031 sponsor interval (`goal_optimizer.py`, `simulation.py`)

Users input a **known or assumed** beginning-2031 whole-portfolio wealth V_2031. Generate two independent annual main-portfolio gross returns for 2031 and 2032, yielding `V_2033 = V_2031 * G_2031 * G_2032`. For each path calculate `FacilityCapacity(V_2033,R,f,F_fixed)`. Show 5th, 50th, 95th percentiles; empirical probabilities `P(capacity >= lower)` and `P(lower <= capacity <= upper)`. A lower percentile is a scenario statistic, **not** automatically a contractual commitment to co-sponsors. Report assumptions, reserve reliability, and downside contingencies before presenting any promise.

## 5. ETF look-through (`portfolio_analysis.py`)

Users must supply an ETF issuer holdings CSV with `ETF,Ticker,Weight` where Weight is a decimal fraction INSIDE the ETF, e.g. 0.015=1.5%. Missing ETF/ticker data are UNKNOWN, not treated as 0. `overlap_table` compares **disclosed** per-ETF holdings with the team's >1.5% filter; this cannot certify compliance if the source is incomplete. Optionally upload the original app's current stock allocation CSV (`Ticker,Allocation (%)`) to obtain the direct stock portion of the 25% stock sleeve. For known ETF constituent weight h_ki, portfolio ETF weights e_k, and direct stock weights d_i (each fraction of total portfolio),

`TotalKnownExposure_i = d_i + sum_k e_k * h_ki`.

There is no live Vanguard constituent scraper; only as-of-dated uploaded disclosures should be used. `TotalKnownExposure_i` is a lower bound with incomplete inputs. The stocks-only optimizer still does NOT apply these as hard optimization constraints.

## 6. Stress and sequence (`stress.py`)

A simple one-year scenario shock is `portfolio_shock = sum(asset_bucket_weight_j * simple_shock_j)`, all buckets explicitly specified; this is linear arithmetic, not historical crisis backtesting. With beginning-year $50k withdrawals and initial $600k, the two-year return sequences −20%, then +25% versus +25%, then −20% yield respectively $487,500 and $510,000. The $22,500 sequence gap appears despite both market-return sequences having cumulative 0%. This demonstration is distinct from the *separate reserve* simulated in section 1.

## 7. Parameter choices

- Whole portfolio forward annual m=6%, s=15%: **illustrative defaults, not derived estimates**.
- Reserve annual m=3%, s=0%: **hypothetical flat-rate illustration; not a guaranteed ladder or ETF yield**.
- Model-specific success target=99% by default: **team assumption**, not a Wharton official requirement.
- Reserve targets 95%, 99%, 99.5%, 99.9% presented for sensitivity.
- Paths=10,000 by default and seed=2026; path count 2,000–50,000 via UI.
- Flexibility fraction=15% and dollar minimum=$50,000: **illustrative policy**, not established by Laura or Wharton.
- The 2031 starting portfolio value is set to the deterministic m-based 2027–2030 illustration, and is **editable**. It is not the actual observed 2031 value.
- Optional direct ETF allocations default to STOCK 25%, VTI 25%, VBR 10%, VXUS 15%, bonds 20%, cash 5% to illustrate the interface, and are **not the team's approved actual allocation**.

## 8. Independent verification and disclosure

Repository pytest plus new scenario tests: **126 passed** in the local environment. Source syntax compiled for all modules and the new Streamlit page. `streamlit.testing` was NOT run because Streamlit was not available in this execution environment and the package could not be installed due disabled network access. Actual Streamlit Cloud/GitHub run is NOT VERIFIED. Tests use numpy 2.3.5, scipy 1.17, pandas 2.2.3 on Python 3.13.5, not the 3.12 cloud environment with requirements.txt pins. Yahoo data and real Treasury rates were not accessed.

A reported “99% funded” is **only** a conditional simulation frequency under the chosen return model and the user's inputs. It must not be treated as 99% certain in the real world. Actual bond cash flows, taxation, future purchasing power, foreign-exchange exposure and real Taiwan property costs are NOT included.
