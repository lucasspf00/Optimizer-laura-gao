"""Liability-reserve-FIRST facility capacity and conditional 2031 range.

This module is separate from the unchanged stock-only Sharpe/Sortino optimizer.
The outputs are model-conditional planning scenarios, NOT a legal commitment.
"""
from __future__ import annotations
import numpy as np
from reserve import required_reserve_by_path, wilson_interval


def facility_capacity(wealth_at_2033: np.ndarray | float, operating_reserve: float,
                      flexibility_fraction: float = 0.15, flexibility_floor: float = 0.) -> np.ndarray:
    """max(wealth - operating reserve - max(floor, fraction*wealth),0).

    A scenario that cannot establish the reserve has ZERO facility capacity.
    """
    wealth = np.asarray(wealth_at_2033, dtype=float)
    values = (float(operating_reserve), float(flexibility_fraction), float(flexibility_floor))
    if not np.all(np.isfinite(wealth)) or np.any(wealth < 0) or not np.all(np.isfinite(values)):
        raise ValueError("Values must be finite, and wealth cannot be negative.")
    if operating_reserve < 0 or not 0 <= flexibility_fraction <= 1 or flexibility_floor < 0:
        raise ValueError("Invalid reserve or capital-flexibility inputs.")
    flex = np.maximum(flexibility_floor, flexibility_fraction * wealth)
    return np.maximum(wealth - operating_reserve - flex, 0.)


def sponsor_range(wealth_at_2033: np.ndarray, operating_reserve: float,
                 flexibility_fraction: float = 0.15, flexibility_floor: float = 0.,
                 lower_percentile: float = 0.05, upper_percentile: float = 0.95) -> dict:
    if not 0 <= lower_percentile < 0.5 < upper_percentile <= 1:
        raise ValueError("Need percentiles spanning the median.")
    caps = facility_capacity(wealth_at_2033, operating_reserve, flexibility_fraction, flexibility_floor)
    if caps.ndim != 1 or caps.size == 0:
        raise ValueError("Expected a nonempty vector of facility capacities.")
    lower, median, upper = np.quantile(caps, [lower_percentile, 0.5, upper_percentile])
    return {
        "Lower ($)": float(lower), "Median ($)": float(median), "Upper ($)": float(upper),
        "Probability at least lower": float(np.mean(caps + 1e-7 >= lower)),
        "Proportion inside range": float(np.mean((caps >= lower-1e-7) & (caps <= upper+1e-7))),
        "Reserve-capable proportion": float(np.mean(wealth_at_2033 + 1e-7 >= operating_reserve)),
    }


def funding_scenario(wealth_at_2033: np.ndarray, reserve_target: float,
                     reserve_gross_returns: np.ndarray, flexibility_fraction: float = 0.15,
                     flexibility_floor: float = 0.) -> dict:
    """Joint funding success: 2033 assets are capped before transfer to reserve.

    Reserve cash is separate, and ten beginning-year liabilities must ALL be met.
    The reserve target is determined in a separate simulation and may not be
    guaranteed; this function estimates scenario success using OUT-OF-SAMPLE draws.
    """
    wealth = np.asarray(wealth_at_2033, dtype=float)
    necessary = required_reserve_by_path(reserve_gross_returns)
    if wealth.shape != necessary.shape or not np.all(np.isfinite(wealth)) or np.any(wealth < 0):
        raise ValueError("Need one nonnegative 2033 wealth amount per reserve-return path.")
    if not np.isfinite(reserve_target) or reserve_target < 0:
        raise ValueError("Invalid reserve target.")
    allocated_reserve = np.minimum(wealth, reserve_target)
    success = allocated_reserve + 1e-7 >= necessary
    caps = facility_capacity(wealth, reserve_target, flexibility_fraction, flexibility_floor)
    n_success = int(np.sum(success))
    return {
        "Estimated full operating success": n_success / len(success),
        "95% conditional sampling interval": wilson_interval(n_success, len(success)),
        "Paths": len(success),
        "Cannot establish target reserve": float(np.mean(wealth + 1e-7 < reserve_target)),
        "Capacity vector ($)": caps,
        "Available for reserve ($)": allocated_reserve,
        "Success mask": success,
    }
