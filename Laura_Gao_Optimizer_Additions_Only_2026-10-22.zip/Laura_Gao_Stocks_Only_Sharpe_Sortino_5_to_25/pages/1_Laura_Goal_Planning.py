"""Additional, separate planning page. The existing app.py + optimizer.py are unchanged.

Run with: streamlit run app.py (from the optimizer subdirectory).
This file appears automatically in Streamlit's sidebar navigation.
"""
from __future__ import annotations
import io
import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st

from simulation import annual_gross_lognormal, full_wealth_until_2033, project_from_known_2031
from reserve import (deterministic_reserve_pv, reserve_sensitivity,
                     stochastic_reserve_quantile, wilson_interval)
from goal_optimizer import facility_capacity, sponsor_range, funding_scenario
from portfolio_analysis import validate_holdings, overlap_table, lookthrough_weights
from stress import one_year_shock, sequence_withdrawals

st.set_page_config(page_title="Laura Gao | Client Goal Planning", page_icon="🏛️", layout="wide")
st.title("Laura Gao · Goal-Based Planning (Additional Page)")
st.warning("SCENARIO MODEL, NOT A CERTIFIED PLAN. This page uses **user-supplied forward return assumptions**. "
           "It does not change or use your existing stock-scoring model or stocks-only Sharpe–Sortino optimizer. "
           "The simulated probabilities are conditional on assumptions and are not guarantees.")

with st.sidebar:
    st.header("Client planning assumptions")
    st.caption("All inputs are illustrative unless the team independently documents their financial basis.")
    growth_mean = st.number_input("Whole-portfolio annual mean return (%)", -50.0, 50.0, 6.0, 0.5) / 100
    growth_vol = st.number_input("Whole-portfolio annual volatility (%)", 0.0, 75.0, 15.0, 1.0) / 100
    reserve_yield = st.number_input("Reserve mean annual return (%)", -20.0, 30.0, 3.0, 0.25) / 100
    reserve_vol = st.number_input("Reserve annual return volatility (%)", 0.0, 40.0, 0.0, 0.5) / 100
    st.caption("0% reserve volatility means a hypothetical fixed annual yield. It is NOT a verified bond ladder or guaranteed ETF yield.")
    target = st.selectbox("Reserve model success target", [0.95, 0.99, 0.995, 0.999], index=1,
                          format_func=lambda x:f"{x:.1%}")
    flex_pct = st.slider("Preserve flexible capital (% of 2033 wealth)", 0, 50, 15, 1) / 100
    flex_floor = st.number_input("Minimum retained flexible capital ($)", 0, 2_000_000, 50_000, 5_000)
    n_paths = st.select_slider("Simulation paths", options=[2000, 5000, 10000, 25000, 50000], value=10000)
    seed = st.number_input("Scenario seed", value=2026, min_value=0, max_value=2_000_000, step=1)

@st.cache_data(show_spinner=False)
def run_scenarios(mean:float,vol:float,rmean:float,rvol:float,n:int,random_seed:int):
    reserve_training = annual_gross_lognormal(rmean,rvol,n,9,random_seed+11)
    growth = annual_gross_lognormal(mean,vol,n,6,random_seed+22)
    reserve_test = annual_gross_lognormal(rmean,rvol,n,9,random_seed+33)
    growth_forward = annual_gross_lognormal(mean,vol,n,2,random_seed+44)
    return reserve_training,growth,reserve_test,growth_forward

try:
    reserve_training,growth,reserve_test,growth_forward = run_scenarios(
        growth_mean,growth_vol,reserve_yield,reserve_vol,int(n_paths),int(seed))
    reserve_target = stochastic_reserve_quantile(reserve_training,target)
    wealth = full_wealth_until_2033(growth)
    funded = funding_scenario(wealth["Beginning 2033 wealth"],reserve_target,reserve_test,
                              flexibility_fraction=flex_pct,flexibility_floor=flex_floor)
except ValueError as exc:
    st.error(f"Scenario-input validation error: {exc}")
    st.stop()

reserve_tab, goals_tab, overlap_tab, stress_tab = st.tabs([
    "2033 operating reserve", "2031–2033 facility scenarios", "ETF overlap (uploaded data)", "Stress illustrations"
])
with reserve_tab:
    st.subheader("2033–2042: ten $50,000 beginning-year payments")
    st.caption("Contributions to the financial portfolio begin with $300,000 in 2027 and $150,000 in 2028. "
               "Before committing facility funds in 2033, the model allocates up to the operating reserve target.")
    c1,c2,c3 = st.columns(3)
    c1.metric("Nominal operating liabilities", "$500,000")
    c2.metric("Flat-yield PV benchmark", f"${deterministic_reserve_pv(reserve_yield):,.0f}")
    c3.metric(f"Modeled {target:.1%} reserve", f"${reserve_target:,.0f}")
    st.info("The flat-yield present value includes the IMMEDIATE 2033 $50,000 payment. The stochastic reserve "
            "is an empirical quantile of simulated liabilities discounted by nine simulated annual reserve returns. "
            "Neither is a quote for actual Treasuries. A bond ETF is not a fixed-maturity Treasury ladder.")
    sensitivity = pd.DataFrame(reserve_sensitivity(reserve_training))
    sensitivity["Target"] = sensitivity["Target"].map(lambda v: f"{v:.1%}")
    sensitivity["Empirical success"] = sensitivity["Empirical success"].map(lambda v: f"{v:.2%}")
    sensitivity["Modeled reserve ($)"] = sensitivity["Modeled reserve ($)"].map(lambda v: f"${v:,.0f}")
    st.dataframe(sensitivity, hide_index=True, use_container_width=True)
    p = funded["Estimated full operating success"]
    lower,upper = funded["95% conditional sampling interval"]
    st.metric("Full-portfolio scenario funding frequency", f"{p:.2%}")
    st.caption(f"95% interval for FINITE-SIMULATION SAMPLING only: {lower:.2%}–{upper:.2%}. "
               f"{funded['Cannot establish target reserve']:.1%} of growth paths cannot fund the target reserve "
               "at the beginning of 2033. This is not a confidence interval for the real world.")

with goals_tab:
    st.subheader("2033 facility capacity, AFTER reserve and retained capital")
    combined = facility_capacity(wealth["Beginning 2033 wealth"],reserve_target,flex_pct,flex_floor)
    c1,c2,c3 = st.columns(3)
    c1.metric("Median beginning-2031 modeled wealth",f"${np.median(wealth['Beginning 2031 wealth']):,.0f}")
    c2.metric("Median beginning-2033 modeled wealth",f"${np.median(wealth['Beginning 2033 wealth']):,.0f}")
    c3.metric("Median 2033 modeled facility capacity",f"${np.median(combined):,.0f}")
    st.caption("Facility capacity = max(2033 assets − reserve target − max(flexible dollar minimum, "
               "flexible % × assets), 0). This protects the separately modeled reserve before facility allocation.")
    st.plotly_chart(px.histogram(pd.DataFrame({"Facility capacity ($)":combined}),
                                   x="Facility capacity ($)",nbins=45,title="Distribution from 2026 assumptions"),
                    use_container_width=True)
    base_2031 = float(full_wealth_until_2033(np.full((1,6),1+growth_mean))["Beginning 2031 wealth"][0])
    known_2031 = st.number_input("Assumed portfolio value known at BEGINNING of 2031 ($)",
                                 min_value=0, max_value=20_000_000, value=int(round(base_2031)),step=10_000)
    conditional_wealth_2033 = project_from_known_2031(float(known_2031),growth_forward)
    sponsor = sponsor_range(conditional_wealth_2033,reserve_target,flex_pct,flex_floor)
    s1,s2,s3=st.columns(3)
    s1.metric("2031 conditional lower 5th percentile", f"${sponsor['Lower ($)']:,.0f}")
    s2.metric("Conditional median", f"${sponsor['Median ($)']:,.0f}")
    s3.metric("Conditional upper 95th percentile", f"${sponsor['Upper ($)']:,.0f}")
    st.caption(f"Modeled probability of meeting or exceeding the lower figure: "
               f"{sponsor['Probability at least lower']:.1%}. Scenarios within [lower,upper]: "
               f"{sponsor['Proportion inside range']:.1%}. A co-sponsor commitment should be more conservative "
               "than a conditional percentile. This is a 2031 scenario using two annual growth draws, "
               "not a firm promise or a present-day forecast of 2031 wealth.")
    st.download_button("Download modeled 2033 facility capacities",pd.DataFrame({
        "Beginning 2033 assets":wealth["Beginning 2033 wealth"],
        "Facility capacity after reserve and flex":combined,
        "Operating obligations fully paid on simulated reserve path":funded["Success mask"],
    }).to_csv(index=False).encode(),file_name="laura_2033_capacity_scenarios.csv",mime="text/csv")

with overlap_tab:
    st.subheader("Whole-portfolio sector/issuer exposure needs CURRENT constituent files")
    st.warning("ETF constituent holdings change. Upload a dated, as-complete-as-possible holdings file; "
               "missing tickers are UNKNOWN, not zero. Uploading a partial file cannot certify the 1.5% rule.")
    st.caption("This is a separate, optional look-through review, not a constraint used by the original optimizer.")
    col1,col2,col3=st.columns(3)
    stock_portfolio_pct=col1.number_input("Individual STOCKS (% of total portfolio)",0.,100.,25.,1.)
    vti_pct=col2.number_input("VTI (% of total portfolio)",0.,100.,25.,1.)
    vbr_pct=col3.number_input("VBR (% of total portfolio)",0.,100.,10.,1.)
    col4,col5,col6=st.columns(3)
    vxus_pct=col4.number_input("VXUS (% of total portfolio)",0.,100.,15.,1.)
    bonds_pct=col5.number_input("Bonds (% of total portfolio)",0.,100.,20.,1.)
    cash_pct=col6.number_input("Cash (% of total portfolio)",0.,100.,5.,1.)
    total=stock_portfolio_pct+vti_pct+vbr_pct+vxus_pct+bonds_pct+cash_pct
    if not np.isclose(total,100,atol=1e-6):
        st.error(f"Entered total allocation is {total:.2f}%, not 100%. Adjust inputs before trusting look-through exposure.")
    else:
        st.caption("Portfolio bucket allocation sums to 100%. Initial bucket values are examples only, "
                   "not a verified allocation from your WInS trades or your ETF/stock model.")
    stock_file=st.file_uploader("Optional current stock optimizer weights CSV: Ticker,Allocation (%)",type="csv",key="stock_weights")
    holdings_file=st.file_uploader("As-of-dated ETF constituent CSV: ETF,Ticker,Weight (decimal fraction; 0.015=1.5%)",
                                   type="csv",key="holdings")
    if holdings_file is not None:
        try:
            holdings=validate_holdings(pd.read_csv(io.BytesIO(holdings_file.getvalue())))
            stock_alloc={}
            tickers=["PGR","MA","CME","WM","ADP","JNJ","ECL","IBM"]
            if stock_file is not None:
                w=pd.read_csv(io.BytesIO(stock_file.getvalue()))
                if not {"Ticker","Allocation (%)"} <= set(w.columns):
                    raise ValueError("Stock optimizer CSV needs Ticker,Allocation (%).")
                if w["Ticker"].duplicated().any():
                    raise ValueError("Duplicate direct-stock ticker.")
                sw=pd.to_numeric(w["Allocation (%)"],errors="raise")
                if not np.all(np.isfinite(sw)) or np.any(sw<0) or not np.isclose(sw.sum(),100,atol=.02):
                    raise ValueError("Optimizer CSV stock weights must total 100% of stock sleeve.")
                stock_alloc={str(t).upper().strip():stock_portfolio_pct/100*float(q)/100
                             for t,q in zip(w["Ticker"],sw)}
                tickers=list(stock_alloc)
            out=overlap_table(holdings,tickers)
            st.dataframe(out,use_container_width=True,hide_index=True)
            st.download_button("Download documented overlap review",out.to_csv(index=False).encode(),
                               file_name="verified_etf_overlap_partial.csv",mime="text/csv")
            if stock_alloc and np.isclose(total,100,atol=1e-6):
                combined=lookthrough_weights({"VTI":vti_pct/100,"VBR":vbr_pct/100,"VXUS":vxus_pct/100},stock_alloc,holdings)
                st.write("**Known direct + disclosed ETF issuer exposure**")
                st.dataframe(combined,use_container_width=True,hide_index=True)
                st.caption("Known combined percentages are LOWER BOUNDS if ETF holdings data are incomplete.")
        except (ValueError,KeyError) as exc:
            st.error(f"Holdings input is invalid: {exc}")
    else:
        st.info("No verified ETF constituent file uploaded; exact VTI/VBR/VXUS overlap cannot be determined from this page.")

with stress_tab:
    st.subheader("Stress-test simple arithmetic (NOT historical scenario calibration)")
    stock_shock=st.slider("Individual stocks shock (%)",-100,30,-35,5)/100
    etf_shock=st.slider("Equity ETFs shock (%)",-100,30,-30,5)/100
    bond_shock=st.slider("Bonds shock (%)",-100,30,-5,5)/100
    cash_shock=st.slider("Cash shock (%)",-100,30,0,5)/100
    st.caption("For illustrative asset-class weights: stocks 25%, ETFs 50%, bonds 20%, cash 5%. "
               "These weights and shocks are assumed, and DO NOT use current prices or bonds' actual duration.")
    shock=one_year_shock({"Stocks":.25,"ETFs":.50,"Bonds":.20,"Cash":.05},
                         {"Stocks":stock_shock,"ETFs":etf_shock,"Bonds":bond_shock,"Cash":cash_shock})
    st.metric("One-period weighted scenario loss",f"{shock:.1%}")
    a,b=sequence_withdrawals(600_000,-.20,.25)
    st.write("**Sequence risk example:** start 2033 with $600,000; pay $50,000 at the BEGINNING of each year.")
    st.caption(f"−20% then +25% ends with ${a:,.0f}; +25% then −20% ends with ${b:,.0f}. "
               f"The difference is ${b-a:,.0f}, despite the same cumulative market return. "
               "This example is not an actual simulated Treasury reserve.")
