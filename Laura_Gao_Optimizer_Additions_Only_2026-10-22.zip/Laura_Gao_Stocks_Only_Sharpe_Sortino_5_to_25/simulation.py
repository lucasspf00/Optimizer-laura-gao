"""Independent scenario return sampling. Does not modify the optimizer.

Annual TOTAL-PORTFOLIO simple return mean/std are externally assumed.
Lognormal gross returns prevent an impossible return below -100%.
"""
from __future__ import annotations
import numpy as np


def annual_gross_lognormal(mean_simple_return: float, simple_volatility: float,
                           n_paths: int, years: int, seed: int) -> np.ndarray:
    """Draw independent annual returns with matched one-year arithmetic E[r], Std[r].

    For gross X=1+r~Lognormal(a,b²): b²=ln(1+(std/(1+mean))²),
    a=ln(1+mean)-b²/2. All parameters are annual, decimal, and constant.
    NOT a calibrated forecast; ignores autocorrelation, crashes and regime shifts.
    """
    mean = float(mean_simple_return)
    std = float(simple_volatility)
    if not np.isfinite(mean) or mean <= -1 or not np.isfinite(std) or std < 0:
        raise ValueError("Annual mean must exceed -100% and volatility must be nonnegative.")
    if not isinstance(n_paths, int) or not 100 <= n_paths <= 500_000:
        raise ValueError("Simulations must range from 100 to 500,000 paths.")
    if not isinstance(years, int) or not 1 <= years <= 100:
        raise ValueError("years must be an integer 1..100.")
    if not isinstance(seed, int) or seed < 0:
        raise ValueError("Provide a nonnegative random seed.")
    log_var = np.log1p((std / (1 + mean)) ** 2)
    log_mean = np.log1p(mean) - 0.5 * log_var
    rng = np.random.default_rng(seed)
    if std == 0:
        return np.full((n_paths, years), 1 + mean, dtype=float)
    return np.exp(log_mean + np.sqrt(log_var) * rng.standard_normal((n_paths, years)))


def full_wealth_until_2033(gross_returns_2027_to_2032: np.ndarray,
                           initial_2027: float = 300_000., additional_2028: float = 150_000.) -> dict:
    """Six 2027–2032 growth years, beginning-of-year contributions exactly timed."""
    gross = np.asarray(gross_returns_2027_to_2032, dtype=float)
    if gross.ndim != 2 or gross.shape[1] != 6 or not np.all(np.isfinite(gross)) or np.any(gross <= 0):
        raise ValueError("Expected (paths,6) positive gross returns for 2027 through 2032.")
    if any(not np.isfinite(v) or v < 0 for v in (initial_2027, additional_2028)):
        raise ValueError("Contributions must be finite and nonnegative.")
    values = np.zeros(gross.shape[0])
    begin_2031 = None
    for col, year in enumerate(range(2027, 2033)):
        if year == 2031:
            begin_2031 = values.copy()
        if year == 2027:
            values += initial_2027
        elif year == 2028:
            values += additional_2028
        values *= gross[:, col]
    return {"Beginning 2031 wealth": begin_2031, "Beginning 2033 wealth": values}


def project_from_known_2031(known_begin_2031: float, gross_returns_2031_to_2032: np.ndarray) -> np.ndarray:
    """Conditional 2031-to-2033 projection, with no new scheduled contributions."""
    if not np.isfinite(known_begin_2031) or known_begin_2031 < 0:
        raise ValueError("2031 beginning wealth must be finite and nonnegative.")
    gross = np.asarray(gross_returns_2031_to_2032, dtype=float)
    if gross.ndim != 2 or gross.shape[1] != 2 or not np.all(np.isfinite(gross)) or np.any(gross <= 0):
        raise ValueError("Expected (paths,2) positive gross return factors.")
    return known_begin_2031 * np.prod(gross, axis=1)
