# Source change manifest and validation evidence

## What is unchanged (byte-identical)

The full source GitHub ZIP was copied into this package. No edits were made to any existing source file. In particular:

- `Laura_Gao_Stocks_Only_Sharpe_Sortino_5_to_25/app.py`
- `Laura_Gao_Stocks_Only_Sharpe_Sortino_5_to_25/optimizer.py`
- `Laura_Gao_Stocks_Only_Sharpe_Sortino_5_to_25/market_data.py`
- `Laura_Gao_Stocks_Only_Sharpe_Sortino_5_to_25/projections.py`
- `Laura_Gao_Stocks_Only_Sharpe_Sortino_5_to_25/requirements.txt`
- All preexisting tests, sample data, existing READMEs and the root repository README.

The original stock optimizer (seeded multi-start, normalized Sharpe–Sortino, 5–25% bounds, unchanged stock-sleeve methodology) is preserved. The stock-scoring −100 to +100 algorithm is not in the supplied GitHub archive, and has therefore not been touched or reverse engineered.

See `SOURCE_SHA256_MANIFEST.csv` for file-by-file ORIGINAL / ADDED classifications and SHA-256 checksums. Any existing file hash should match the source ZIP.

## What is added

| New path (relative to existing optimizer folder) | Role |
|---|---|
| `reserve.py` | Correct dated operating-liability PV; scenario reserve quantiles, independence check, Wilson sample interval |
| `simulation.py` | Positive gross return generation and correct beginning-year client contributions |
| `goal_optimizer.py` | Separate-reserve-first facility capacity, 2031 conditional range, joint funding scenario |
| `portfolio_analysis.py` | Dated uploaded ETF holding overlap; known whole-portfolio issuer exposure |
| `stress.py` | Basic deterministic full-portfolio shock and sequence risk |
| `pages/1_Laura_Goal_Planning.py` | New optional Streamlit page without modifying original `app.py` |
| `tests/test_goal_upgrade.py` | Additional independent unit and numerical tests |
| `UPGRADE_METHODS.md` | Full equations, assumptions, limitations, and source mapping |
| Root `GITHUB_UPGRADE_README.md` | GitHub upload, deployment and branch guidance |
| Root `CHANGES_AND_VERIFICATION.md` | This signed-off-style but non-certification change log |
| Root `SOURCE_SHA256_MANIFEST.csv` | Original vs added file hashes |

## Executed verification

`python -m pytest -q` in `Laura_Gao_Stocks_Only_Sharpe_Sortino_5_to_25/`:

    126 passed in 3.18s

This combines the original 85 tests with 41 new tests in `test_goal_upgrade.py`. Main arithmetic checked: ten liability payments at beginning of year; 0% and 3% reserve PV; exact 2031 and 2033 values with deterministic 6% return; stochastic reserve ordering and empirical target frequency; independent means and vol of generated gross returns; reserve-first facility limit; 2031 sponsor interval; joint growth/liability success; ETF missing-value handling and issuer exposure; and numerical effect of different withdrawal-return sequences.

`python -m py_compile` completed successfully on all production modules and the new page. Browser/rendered Streamlit testing is **NOT VERIFIED**; Streamlit is unavailable in the local environment, and attempted package installation was blocked by offline networking. The unmodified original Streamlit smoke test passes under its existing mock strategy and cannot substitute for real UI execution.

## Remaining model limitations — not a guarantee

- Forward whole-portfolio arithmetic mean/volatility are supplied manually; **no ETF/bond/stocks covariance estimation** is integrated into these assumptions.
- Reserve path returns are simulated independent of main-portfolio returns. Correlated crises, sequence regimes, Taiwan foreign-exchange risks, taxation, and transaction costs are not represented.
- The bond/reserve yield is a hypothetical return assumption, not security-by-security cash-flow matching of priced Treasuries or assurance about a rolling ETF.
- The original stock-only optimizer does **not** enforce whole-portfolio ETF constituent restrictions or sector caps. The additional page reports known holdings for manual review only.
- The 2031 interval is computed conditional on an entered 2031 wealth value. It is not a probability-validated unconditional forecast or a binding monetary promise.
- The existing scoring algorithm and its fundamental, risk and final scores cannot be audited or integrated without its separate code.
- Original simulator `projections.py` intentionally remains unchanged and can still run facility what-if amounts that would impair future obligations. The new page adds a separate reserve-first recommendation and does not fix or constrain the ORIGINAL what-if function.
- No real Streamlit deployment, Yahoo feed, Vanguard fund constituent download or WInS execution has been validated as part of this package.

**Deployment stance:** optional planning research enhancement, not a production-certified full goal-based optimizer. Keep `main` unchanged until branch validation in your environment.
